package pe.edu.uni.apieduca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApieducaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApieducaApplication.class, args);
	}

}
